const setup = () => {
// deze code wordt pas uitgevoerd als de pagina volledig is ingeladen
    let passagiers = document.getElementById("passagiers").textContent.toLowerCase();
    let aantal = passagiers.length;

    let optel = 0;
    while(aantal < passagiers.length){
        let zitplaatsen = passagiers[optel] +"--"+ passagiers[optel++];
        optel += 2;
        console.log(zitplaatsen);
    }
    //if(passagiers %2 === 0 && ){
        //console.log("nieuw karretje")
   // }

}

window.addEventListener("load", setup);

